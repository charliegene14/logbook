-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 01, 2021 at 03:27 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cahier_de_bord`
--

-- --------------------------------------------------------

--
-- Table structure for table `activ_ip`
--

CREATE TABLE `activ_ip` (
  `Id` int(11) NOT NULL,
  `ipAddr` varchar(255) NOT NULL,
  `dateVisit` date NOT NULL,
  `timeVisit` time NOT NULL,
  `view` text NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `ipHost` text,
  `userAgent` text,
  `accptLang` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `category_post`
--

CREATE TABLE `category_post` (
  `Type` int(11) NOT NULL,
  `nameCat` varchar(255) NOT NULL,
  `colorCat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `infos`
--

CREATE TABLE `infos` (
  `idInfo` int(11) NOT NULL,
  `nameInfo` varchar(255) NOT NULL,
  `contentInfo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `infos`
--

INSERT INTO `infos` (`idInfo`, `nameInfo`, `contentInfo`) VALUES
(1, 'Accueil', 'Welcome home'),
(2, 'Head', 'Logbook'),
(3, 'Foot', '(<a href=\'admin/\'><span style=\'color:#ffffff\'>Admin</span></a>)');

-- --------------------------------------------------------

--
-- Table structure for table `navigation`
--

CREATE TABLE `navigation` (
  `idNav` int(11) NOT NULL,
  `nameNav` varchar(255) NOT NULL,
  `linkNav` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `navigation`
--

INSERT INTO `navigation` (`idNav`, `nameNav`, `linkNav`) VALUES
(0, 'Accueil', 'index.php'),
(1, 'Articles', 'index.php?view=posts');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `idPage` int(11) NOT NULL,
  `titlePage` varchar(255) NOT NULL,
  `fileName` varchar(255) NOT NULL,
  `contentPage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `passwds`
--

CREATE TABLE `passwds` (
  `idPass` int(11) NOT NULL,
  `namePass` varchar(255) NOT NULL,
  `thePass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `passwds`
--

INSERT INTO `passwds` (`idPass`, `namePass`, `thePass`) VALUES
(1, 'Site', '$2y$10$m9eUDRNu7vk8Z8I9GnOXl.X5tb1psiSLGAKCOvV6qeu5wB2gIaMAS'),
(2, 'Admin', '$2y$10$jJrGl4EWv9089CNgzBDfXu2D4WP5Y36uN36s2/EBpq3yiN1MD4n.W');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `idPost` int(11) NOT NULL,
  `Type` int(11) DEFAULT NULL,
  `Work` int(11) DEFAULT NULL,
  `Tool` int(11) DEFAULT NULL,
  `timePost` time NOT NULL,
  `titlePost` varchar(255) NOT NULL,
  `datePost` date NOT NULL,
  `contentPost` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `idTool` int(11) NOT NULL,
  `nameTool` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `work_parts`
--

CREATE TABLE `work_parts` (
  `typeCat` int(11) DEFAULT NULL,
  `idWork` int(11) NOT NULL,
  `nameWork` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activ_ip`
--
ALTER TABLE `activ_ip`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `category_post`
--
ALTER TABLE `category_post`
  ADD PRIMARY KEY (`Type`);

--
-- Indexes for table `infos`
--
ALTER TABLE `infos`
  ADD PRIMARY KEY (`idInfo`);

--
-- Indexes for table `navigation`
--
ALTER TABLE `navigation`
  ADD PRIMARY KEY (`idNav`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`idPage`);

--
-- Indexes for table `passwds`
--
ALTER TABLE `passwds`
  ADD PRIMARY KEY (`idPass`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`idPost`),
  ADD KEY `type categorie` (`Type`),
  ADD KEY `link to work` (`Work`),
  ADD KEY `link to tool` (`Tool`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`idTool`);

--
-- Indexes for table `work_parts`
--
ALTER TABLE `work_parts`
  ADD PRIMARY KEY (`idWork`),
  ADD KEY `lien à la catégorie` (`typeCat`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activ_ip`
--
ALTER TABLE `activ_ip`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_post`
--
ALTER TABLE `category_post`
  MODIFY `Type` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `infos`
--
ALTER TABLE `infos`
  MODIFY `idInfo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `navigation`
--
ALTER TABLE `navigation`
  MODIFY `idNav` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `idPage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `passwds`
--
ALTER TABLE `passwds`
  MODIFY `idPass` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `idPost` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `idTool` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `work_parts`
--
ALTER TABLE `work_parts`
  MODIFY `idWork` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `link to tool` FOREIGN KEY (`Tool`) REFERENCES `tools` (`idTool`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `link to work` FOREIGN KEY (`Work`) REFERENCES `work_parts` (`idWork`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `type categorie` FOREIGN KEY (`Type`) REFERENCES `category_post` (`Type`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
