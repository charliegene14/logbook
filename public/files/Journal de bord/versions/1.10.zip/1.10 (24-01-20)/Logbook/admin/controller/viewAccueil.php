<?php
require_once 'model/dbInfos.php';
require_once 'model/regex.php';

function viewAccueil()
{
	$regex = new Regex();
	$infos = new dbInfo();
	$list_infos = $infos->getList();

	if (!empty($_GET['update']))
	{
		header('Location: index.php');
		$nameInfo = $_GET['update'];
		$infos->updateContent($nameInfo, $regex->fromBBCode($_POST[$nameInfo]));
		exit();
	}

	require 'view/viewAccueil.php';
}