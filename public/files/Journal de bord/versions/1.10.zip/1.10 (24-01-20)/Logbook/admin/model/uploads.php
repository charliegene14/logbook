<?php

class UploadsPage
{
	public function numberOfImg($idPage)
	{
		$numberOfImg = count(glob("../public/img/pages/$idPage-*"));
		return $numberOfImg;
	}

	public function uploadImg($idPage)
	{
		$targetDir = '../public/img/pages/';

		for ($i=0; $i<count($_FILES['img']['name']); $i++)
		{
			$nb = count(glob($targetDir . "$idPage-*"));

			$oldName = explode('.', $_FILES['img']['name'][$i]);
			$newName = $idPage.'-'.$nb.'.'.end($oldName);

			$targetFile = $targetDir . $newName;
			move_uploaded_file($_FILES['img']['tmp_name'][$i], $targetFile);
		}
	}
}

class UploadsPost
{
	public function numberOfImg($idPost)
	{
		$numberOfImg = count(glob("../public/img/posts/$idPost-*"));
		return $numberOfImg;
	}

	public function uploadImg($idPost)
	{
		$targetDir = '../public/img/posts/';

		for ($i=0; $i<count($_FILES['img']['name']); $i++)
		{
			$nb = count(glob($targetDir . "$idPost-*"));

			$oldName = explode('.', $_FILES['img']['name'][$i]);
			$newName = $idPost.'-'.$nb.'.'.end($oldName);

			$targetFile = $targetDir . $newName;
			move_uploaded_file($_FILES['img']['tmp_name'][$i], $targetFile);
		}
	}
}
