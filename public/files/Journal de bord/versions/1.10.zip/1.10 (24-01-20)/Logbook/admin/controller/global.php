<?php
require_once 'model/dbPasswords.php';
require_once 'model/dbActivity.php';

function isValidPass($namePass)
{
	$dbPassword = new dbPassword();

	if (empty($_SESSION[$namePass]) OR $_SESSION[$namePass] != $dbPassword->getPass($namePass))
	{
		return false;
	}
	return true;
}

function Error($message)
{
	require('view/viewError.php');
}

function Workinprogress()
{
	require 'view/viewWorking.php';
}

function newActivity()
{
	$activity = new ActivityIP();
	$activity->getActivity();
}