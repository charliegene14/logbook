<?php $pageTitle = 'Panel'; ?>
<?php ob_start(); ?>

<section class="viewPanel">

	<article class="choicePanel">
		<p>Bienvenue admin :)</p>
		<p><a href="index.php?view=activities">Voir les activités client sur le site</a></p>
		<p><a href="index.php?view=pages">Gestionnaire de pages.</a></p>
		<p><a href="index.php?view=navigation">Gestionnaire du menu de navigation.</a></p>
		<p><a href="index.php?view=cats">Gestionnaire des catégories, parties, outils.</a></p>
		<p><a href="index.php?view=posts">Gestionnaire d'articles.</a></p>
	</article>

	<?php
	while ($INFO = $list_infos->fetch())
	{
		echo '
			<article class="updateInfos">
				<form method="post" action="index.php?update='.$INFO['nameInfo'].'">
						<fieldset>
							<legend>' .$INFO['nameInfo']. '</legend>
								<p>
									<textarea rows="15" cols="100" name="'.$INFO['nameInfo'].'">'.$regex->toBBCode($INFO['contentInfo']).'</textarea><br />
									<input type="submit" value="Valider" />
								</p>
						</fieldset>
				</form>
			</article>';
	}
	?>
</section>

<?php $pageContent = ob_get_clean(); ?>
<?php require('template.php'); ?>