<?php

require_once 'model/database.php';

class dbCategories extends database
{
	public function getAll()
	{
		$DB = $this->dbConnect();
		$QUERY = $DB->query('SELECT * FROM category_post');
		return $QUERY;
	}

	public function getByTool($idTool)
	{
		$DB= $this->dbConnect();
		$QUERY = $DB->prepare("SELECT cp.Type, cp.nameCat
								FROM category_post cp
								INNER JOIN post p 
								ON cp.Type = p.Type
								WHERE p.Tool = ?
								GROUP BY cp.Type");

		$QUERY->execute(array($idTool));
		return $QUERY;
	}

	public function getByWork($idWork)
	{
		$DB= $this->dbConnect();
		$QUERY = $DB->prepare("SELECT cp.Type, cp.nameCat
								FROM category_post cp
								INNER JOIN post p 
								ON cp.Type = p.Type
								WHERE p.Work = ?
								GROUP BY cp.Type");

		$QUERY->execute(array($idWork));
		return $QUERY;
	}
}