<?php
	function activityIp()
	{
		$DB = dbConnect();
		$TABLE = 'activ_ip';
		$ip = getIP();
		$DATE = '"'.date('Y-m-d').'"';
		$TIME = '"'.date('H:i:s').'"';
		$view = '"'.$_SERVER['REQUEST_URI'].'"';
		$method = '"'.$_SERVER['REQUEST_METHOD'].'"';
		$host = '"'.gethostbyaddr($ip).'"';
		$userAgent = '"'.$_SERVER['HTTP_USER_AGENT'].'"';
		$lang = '"'.$_SERVER['HTTP_ACCEPT_LANGUAGE'].'"';

		$COLS = 'Id, ipAddr, dateVisit, timeVisit, view, method, ipHost, userAgent, accptLang';
		$VALUES = 'NULL, "'.$ip.'", '.$DATE.', '.$TIME.', '.$view.', '.$method.', '.$host.', '.$userAgent.', '.$lang.'';
		$RECORD = insertTable($TABLE, $COLS, $VALUES);
	}

	function getIP()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP']) && $_SERVER['HTTP_CLIENT_IP'] != $ip)
		{
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] != $ip)
		{
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else
		{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}

	function regexPreviewPost($string)
	{
		$string = preg_replace('#\<strong\>(.+)\</strong\>#isU', '$1', $string); //bold
		$string = preg_replace('#\<i\>(.+)\</i\>#isU', '$1', $string); //italic
		$string = preg_replace('#\<u\>(.+)\</u\>#isU', '$1', $string); //underline
		$string = preg_replace('#\<s\>(.+)\</s\>#isU', '$1', $string); //crossout
		$string = preg_replace('#\<p\>(.+)\</p\>#isU', '$1', $string); //paragraph
		$string = preg_replace('#\<img src\=\'([^(public/css/smileys/)].+)\' /\>#isU', '' , $string); //image 
		$string = preg_replace('#\<img width\=\'([0-9]{1,2})\%\' height=\'([0-9]{1,2})\%\' src\=\'(.+)\' /\>#isU', '' , $string); //image with size 
		$string = preg_replace('#\<br /\>#isU', '' , $string); //br
		$string = preg_replace('#\<span style\=\'color\:\#([a-f0-9]{6})\'\>(.+)\</span\>#isU', '$2', $string); //color
		$string = preg_replace('#\<div style\=\'text\-align\:(left|right|center|justify)\'\>(.+)\</div\>#isU', '$2', $string); //align
		$string = preg_replace('#\<div style\=\'float\:(right|left)\'\>(.+)\</div\>#isU', '$2' , $string); //float
		$string = preg_replace('#\<fieldset\>\<legend\>(.+)\</legend\>(.+)\</fieldset\>#isU', '$2' , $string); //fieldset with name
		$string = preg_replace('#\<fieldset\>(.+)\</fieldset\>#isU', '$1' , $string); //fieldset without name
		$string = preg_replace('#\<a href\=\'(.+)\'\>(.+)\</a\>#isU', '$2' , $string); //link

		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/smile.png\' /\>#isU', ':)' , $string); // :)
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/wink.png\' /\>#isU', ';)' , $string); // ;)
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/flat.png\' /\>#isU', ':|' , $string); // :|
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/cry.png\' /\>#isU', ':\'(' , $string); // :'(
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/sad.png\' /\>#isU', ':(' , $string); // :(
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/quiet.png\' /\>#isU', ':X' , $string); // :X
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/doubts.png\' /\>#isU', ':/' , $string); // :/
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/happy.png\' /\>#isU', ':D' , $string); // :D
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/happy2.png\' /\>#isU', '' , $string); // xD
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/confused.png\' /\>#isU', ':S' , $string); // :S
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/tongue.png\' /\>#isU', ':P' , $string); // :P
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/surprised.png\' /\>#isU', ':O' , $string); // :O
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/mad.png\' /\>#isU', 'x(' , $string); // x(
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/bored.png\' /\>#isU', '' , $string); // -.-
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/ninja.png\' /\>#isU', '^:' , $string); // ^:
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/angry.png\' /\>#isU', '' , $string); // xO
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/suspicious.png\' /\>#isU', '' , $string); // o_O
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/nerd.png\' /\>#isU', '' , $string); // ._.
		return $string;
	}

	function regexDate($string)
	{
		$string = preg_replace('#([0-3][0-9]{3})-([0-1][0-9])-([0-3][0-9])#isU', '$3/$2/$1' , $string);
		return $string;
	}

	function regexTime($string)
	{
		$string = preg_replace('#([0-2][0-9]):([0-5][0-9]):00#isU', '$1h$2min' , $string);
		return $string;
	}

/*Return null if choosen ID doesn't exist. */
	function getFullpost($idPost)
	{
		$DB = dbConnect();

		$REQ_POST = $DB->prepare('SELECT * FROM post p
								INNER JOIN category_post cp
								ON p.Type = cp.Type
								LEFT JOIN work_parts wp
								ON p.Work = wp.idWork
								LEFT JOIN tools t
								ON p.Tool = t.idTool
								WHERE idPost = '.$idPost.'');

 		$REQ_VERIF_EXIST = $DB->prepare('SELECT COUNT(idPost) AS NBID FROM post p WHERE idPost = ' .$idPost. '');
 		$REQ_VERIF_EXIST->execute();

 		if ($REQ_VERIF_EXIST->fetch()['NBID'] == 1)
		{
			$REQ_POST->execute();
			return $REQ_POST;
		}
	}

/*Set the param $wherePost with the entire content of WHERE query like 'Type IS NOT NULL' or 'Work = 2'.
 Call $displayPagination to display page selection in the view.
Eg. getPosts('WHERE Tool = 1 AND Type IS NOT NULL')*/
	function getPosts($wherePost, $postByPage)
	{

		$DB = dbConnect();

		$REQ_TOTAL_POSTS = $DB->prepare('SELECT COUNT(idPost) AS total FROM post p WHERE '.$wherePost.' ');
		$REQ_TOTAL_POSTS->execute();
		$TOTAL_POSTS = $REQ_TOTAL_POSTS->fetch()['total'];
		$TOTAL_PAGE = ceil($TOTAL_POSTS / $postByPage);

		if(isset($_GET['pagint']) AND intval($_GET['pagint']) AND $_GET['pagint'] > 0)
		{
			$PAGE_NOW = $_GET['pagint'];
			if ($PAGE_NOW > $TOTAL_PAGE)
			{
				throw new Exception('Désolé, la page demandée n\'éxiste pas.');
			}
		}
		else
		{
			$PAGE_NOW = 1;
		}

		$FIRST_POST = ($PAGE_NOW - 1) * $postByPage;

		$REQ_POSTS = $DB->prepare('SELECT * FROM post p
							INNER JOIN category_post cp
							ON p.Type = cp.Type
							LEFT JOIN work_parts wp
							ON p.Work = wp.idWork
							LEFT JOIN tools t
							ON p.Tool = t.idTool
							WHERE '.$wherePost.'
							ORDER BY p.idPost DESC
							LIMIT '.$FIRST_POST.', '.$postByPage.'');

		$REQ_POSTS->execute();

		ob_start();
			for($PAGE=1; $PAGE <= $TOTAL_PAGE; $PAGE++)
			{
				if ($PAGE == $PAGE_NOW)
				{
				echo ' <strong> ' .$PAGE. ' </strong> ';
				}
				else
				{
					echo ' <a href="index.php?view=posts';
						if (!empty($_GET['type']) && intval($_GET['type']))
						{
							echo '&amp;type='.$_GET['type'].'';
						}

						if (!empty($_GET['work']) && intval($_GET['work']))
						{
							echo '&amp;work='.$_GET['work'].'';
						}

						if (!empty($_GET['tool']) && intval($_GET['tool']))
						{
							echo '&amp;tool='.$_GET['tool'].'';
						}

						echo '&amp;pagint='.$PAGE.'"> '.$PAGE.' </a>';
				}
			}
		$displayPagination = ob_get_clean();

		return [$REQ_POSTS, $TOTAL_PAGE, $PAGE_NOW, $displayPagination];
	}

	function isExist($tableName, $column)
	{
		$DB = dbConnect();
		$COUNT = $DB->prepare('SELECT COUNT('.$column.') AS number FROM '.$tableName.' ');
		$COUNT->execute();
		$RESULT = $COUNT->fetch()['number'];
		
		if ($RESULT >= 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

/*SELECT all elements of a choosen table in a simple query. Set a table. Need to be placed in a var and fetch it later.
Eg. $TABLE = getTable('posts'); then $TABLE->fetch()*/
	function getTable($tableName)
	{
		$DB = dbConnect();
		$QUERY = $DB->prepare('SELECT * FROM '.$tableName.' ');
		$QUERY->execute();
		return $QUERY;
	}

/*If you want to insert in a existing ID, use before rowExist() function*/
	function insertTable($table, $columns, $values)
	{
		$DB = dbConnect();
		$INSERT = $DB->prepare('INSERT INTO '.$table.' ('.$columns.') VALUES ('.$values.') ');
		$INSERT->execute();
	}

	function updateTable($table, $set, $where)
	{
		$DB = dbConnect();
		$UPDATE = $DB->prepare('UPDATE '.$table.' SET '.$set.' WHERE '.$where.' ');
		$UPDATE->execute();
	}

/*Get content of "infos" table in a string. Set a nameInfo. Need to echo.
Eg. echo getInfos('Accueil');*/

	function getInfos($nameInfo)
	{
		$DB = dbConnect();

		$REQ_INFOS = $DB->prepare('SELECT contentInfo FROM infos WHERE nameInfo= ? ');
		$REQ_INFOS->execute(array($nameInfo));

		$CONTENT_INFO = $REQ_INFOS->fetch()['contentInfo'];

		return $CONTENT_INFO;
	}

/*Check if is entered a correct or wrong passwd. Set a valid namePass of your choice in the associated table.
With a html form, post method, send the var 'password'*/
	function validPass($namePass)
	{
		if (isset($_POST['password']) AND strval($_POST['password']) AND strlen($_POST['password']) < 16)
		{
			session_start();
			$DB = dbConnect();

			$REQ_PASSWD = $DB->prepare('SELECT thePass FROM passwds WHERE namePass = ?');

			$PASSWD_TYPE = htmlspecialchars($_POST['password']);
			$REQ_PASSWD->execute(array($namePass));
			$PASSWD = $REQ_PASSWD->fetch()['thePass'];

			if ($PASSWD_TYPE === $PASSWD)
			{
				header('Location: index.php');
				$_SESSION[''.$namePass.''] = $PASSWD;
				exit();
			}
			else
			{
				header('Location: index.php');
				exit();
			}
		}
	}

/*Compare the session cookie with table password. Security. Return true or false*/
	function isValidPass($namePass)
	{
		$DB = dbConnect();

		$REQ_PASSWD = $DB->prepare('SELECT thePass FROM passwds WHERE namePass = ?');
		$REQ_PASSWD->execute(array($namePass));
		$PASSWD = $REQ_PASSWD->fetch()['thePass'];

		if(isset($_SESSION[''.$namePass.'']) && $_SESSION[''.$namePass.''] === $PASSWD)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

/*Connect to the database. Catch error if doesn't work.*/
	function dbConnect()
	{
		try
		{
			$DB =  new PDO('mysql:host=localhost;dbname=cahier_de_bord;charset=utf8', 'root', 'root', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			return $DB;
		}
		catch(Exception $e)
		{
			die('Erreur: ' . $e->getMessage());
		}
	}
