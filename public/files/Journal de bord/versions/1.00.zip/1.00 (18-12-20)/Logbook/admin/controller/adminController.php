<?php
require 'model/model.php'; //Get the model for MVC architecturing

function Error()
{
	require 'view/viewError.php';
}

function viewBlock()
{
	validPass('Admin');
	require 'view/viewBlock.php';
}

function viewPanel()
{
	$TABLE = 'infos';
	$REQ_INFOS = getTable($TABLE);

	if (!empty($_GET['update']))
	{
		header('Location: index.php');
		$nameInfo = $_GET['update'];
		$SET = 'contentInfo = "'.fromBBCode($_POST[$nameInfo]).'"';
		$WHERE = 'nameInfo = "'.$nameInfo.'"';
		updateTable($TABLE, $SET , $WHERE);
		exit();
	}
	require 'view/viewPanel.php';
}

function viewConnectedDetails()
{
	$DB = dbConnect();
	$REQ_DETAILS_LIST = $DB->prepare('SELECT * FROM activ_ip WHERE ipAddr = ? AND dateVisit = ? ORDER BY timeVisit DESC');
	if (empty($_GET['date']))
	{
		header('Location: index.php?view=connected&ip='.getIp().'&date='.date('Y-m-d').'');
		exit();
	}
	else
	{
		$REQ_DETAILS_LIST->execute(array($_GET['ip'], $_GET['date']));
	}

	require 'view/viewConnectedDetails.php';
}

function viewConnectedDate()
{
	$DB = dbConnect();
	$REQ_DATE_LIST = $DB->prepare('SELECT dateVisit, COUNT(view) AS viewsDate FROM activ_ip WHERE ipAddr = ? GROUP BY dateVisit DESC');
	if (empty($_GET['ip']))
	{
		header('Location: index.php?view=connected&ip='.getIp().'&date='.date('Y-m-d').'');
		exit();
	}
	else
	{
		$REQ_DATE_LIST->execute(array($_GET['ip']));
	}
	require 'view/viewConnectedDate.php';
}

function viewConnected()
{
	$DB = dbConnect();
	$REQ_IP_LIST = $DB->query('SELECT ipAddr, MAX(dateVisit) AS lastVisit, COUNT(view) AS totalViews FROM activ_ip GROUP BY ipAddr ORDER BY lastVisit DESC');
	$REQ_TOTAL_VISIT = $DB->query('SELECT Id, COUNT(ipAddr) AS totalIp FROM activ_ip GROUP BY Id');

	require 'view/viewConnected.php';
}

function viewPageContent()
{
	if (!isset($_GET['id']) OR !intval($_GET['id']))
	{
		header('Location: index.php?view=error');
		exit();
	}
	else
	{
		$ID = $_GET['id'];
		$REQ_PAGE = getTable('pages WHERE idPage='.$ID.'');
		$PAGE = $REQ_PAGE->fetch();
		$numberOfImg = count(glob('../public/img/pages/'.$PAGE['titlePage'].'*'));

		if (isset($_GET['update']))
		{	
			header('Location: index.php?view=pagecontent&id='.$ID.'');
			$GCONTENT = 'contentPage = "'.$_POST['contentPost'].'"';

			$SET = ''.$GCONTENT.'';
			$WHERE = 'idPage = '.$ID.'';
			uploadImg($PAGE['titlePage'], 'pages/');
			updateTable('pages', $SET, $WHERE);
			exit();
		}
	}
	require 'view/viewPageContent.php';
}

function viewPages()
{
	$TABLE = 'pages';
	$REQ_PAGES = getTable($TABLE);

	if (!empty($_GET['update']) AND intval($_GET['update']))
	{
		header('Location: index.php?view=pages');
		$ID = $_GET['update'];
		
		$SET = 'titlePage = "'.$_POST['title'.$ID.''].'", fileName = "'.$_POST['file'.$ID.''].'"';
		$WHERE = 'idPage = '.$ID.'';
		updateTable($TABLE, $SET, $WHERE);
		exit();
	}

	elseif (isset($_GET['insert']))
	{
		header('Location: index.php?view=pages');
		$TITLE = ''.$_POST['titlePage'].'';
		$FILE = ''.$_POST['fileName'].'';

		$COLS = 'idPage, titlePage, fileName, contentPage';
		$VALUES = 'NULL, "'.$TITLE.'", "'.$FILE.'", "<p>To write...</p>"';
		insertTable($TABLE, $COLS, $VALUES);
		exit();
	}

	elseif (!empty($_GET['del']) AND intval($_GET['del']))
	{
		header('Location: index.php?view=pages');
		$ID = $_GET['del'];
		deleteTable($TABLE, 'idPage', $ID);
		exit();
	}
	require 'view/viewPages.php';
}

function viewNavigation()
{
	$TABLE = 'navigation';
	$REQ_MENU = getTable($TABLE);


	if (!empty($_GET['update']) AND intval($_GET['update']))
	{
		header('Location: index.php?view=navigation');
		$idNav = $_GET['update'];

		$SET = 'nameNav = "'.$_POST['name'.$idNav.''].'", linkNav = "'.$_POST['link'.$idNav.''].'"';
		$WHERE = 'idNav = '.$idNav.'';
		updateTable($TABLE, $SET, $WHERE);
		exit();
	}

	elseif (isset($_GET['insert']))
	{
		header('Location: index.php?view=navigation');
		$ID = $_POST['id'];
		$NAME = ''.$_POST['name'].'';
		$LINK = ''.$_POST['link'].'';

		$COLS = 'idNav, nameNav, linkNav';
		$VALUES = '"'.$ID.'", "'.$NAME.'", "'.$LINK.'"';
		rowExist($TABLE, 'idNav', $ID);
		insertTable($TABLE, $COLS, $VALUES);
		exit();
	}

	elseif (!empty($_GET['del']) AND intval($_GET['del']))
	{
		header('Location: index.php?view=navigation');
		$ID = $_GET['del'];
		deleteTable($TABLE, 'idNav', $ID);
		exit();
	}
	elseif (!empty($_GET['up']) AND intval($_GET['up']))
	{
		header('Location: index.php?view=navigation');
		$ID = $_GET['up'];
		moveRow('UP', $TABLE, 'idNav', $ID);
		exit();
	}
	elseif (!empty($_GET['down']) AND intval($_GET['down']))
	{
		header('Location: index.php?view=navigation');
		$ID = $_GET['down'];
		moveRow('DOWN', $TABLE, 'idNav', $ID);
		exit();
	}
	require 'view/viewNavigation.php';
}

function viewPostUpdate()
{
	if (!isset($_GET['id']) OR !intval($_GET['id']))
	{
		header('Location: index.php?view=error');
		exit();
	}
	else
	{
		$ID = $_GET['id'];
		[$REQ_POST, $TOTAL_PAGE, $PAGE_NOW] = getPosts('idPost='.$ID.'', 1);
		$POST = $REQ_POST->fetch();

		$TABLE_CATS = getTable('category_post');
		$TABLE_WORKS = getTable('work_parts WHERE typeCat ='.$POST['Type'].'');
		$TABLE_TOOLS = getTable('tools');

		$numberOfImg = count(glob('../public/img/posts/'.$POST['titlePost'].'*'));

		if (isset($_GET['update']))
		{	
			header('Location: index.php?view=postupdate&id='.$ID.'');
			$GTYPE = 'Type = '.$_POST['Type'].'';
			$GWORK = 'Work = '.$_POST['Work'].'';
			$GTOOL = 'Tool = '.$_POST['Tool'].'';
			$GTIME = 'timePost = "'.$_POST['timePost'].'"';
			$GTITLE = 'titlePost = "'.htmlspecialchars($_POST['titlePost']).'"';
			$GDATE = 'datePost = "'.$_POST['datePost'].'"';
			$GCONTENT = 'contentPost = "'.fromBBCode(''.$_POST['contentPost'].'').'"';

			$SET = ''.$GTYPE.', '.$GWORK.', '.$GTOOL.', '.$GTIME.', '.$GTITLE.', '.$GDATE.', '.$GCONTENT.'';
			$WHERE = 'idPost = '.$ID.'';
			uploadImg($_POST['titlePost'], 'posts/');
			updateTable('post', $SET, $WHERE);
			exit();
		}
		elseif (isset($_GET['del']))
		{
			header('Location: index.php?view=posts');
			deleteTable('post', 'idPost', $ID);
			exit();
		}
		require 'view/viewPostUpdate.php';
	}

}

function viewPostInsert()
{
	$TABLE_CATS = getTable('category_post');
	$TABLE_WORKS = getTable('work_parts');
	$TABLE_TOOLS = getTable('tools');

	if (isset($_GET['insert']))
	{
		header('Location: index.php?view=posts');
		$GTYPE = ''.$_POST['Type'].'';
		$GWORK = ''.$_POST['Work'].'';
		$GTOOL = ''.$_POST['Tool'].'';
		$GTIME = '"'.$_POST['timePost'].'"';
		$GTITLE = '"'.htmlspecialchars($_POST['titlePost']).'"';
		$GDATE = '"'.$_POST['datePost'].'"';
		$GCONTENT = '"'.fromBBCode(''.$_POST['contentPost'].'').'"';		

		$COLS = 'idPost, Type, Work, Tool, timePost, titlePost, datePost, contentPost';
		$VALUES = 'NULL, '.$GTYPE.', '.$GWORK.', '.$GTOOL.', '.$GTIME.', '.$GTITLE.', '.$GDATE.', '.$GCONTENT.' ';
		uploadImg($_POST['titlePost'], 'posts/');
		insertTable('post', $COLS, $VALUES);
		exit();
	}
	require 'view/viewPostInsert.php';
}

function viewPosts()
{
		///
		if (!empty($_GET['type']) && intval($_GET['type']) && empty($_GET['work']) && empty($_GET['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
			$SET = 'p.Type = '.$_GET['type'].'';
		}
		elseif (!empty($_POST['type']) && intval($_POST['type']) && empty($_POST['work']) && empty($_POST['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
			$SET = 'p.Type = '.$_POST['type'].'';
			$_GET['type'] = $_POST['type'];
		}

		///
		elseif (empty($_GET['type']) && empty($_GET['work']) && !empty($_GET['tool']) && intval($_GET['tool']))
		{
			$WHEREWORKS = 'typeCat IS NULL';
			$SET = 'p.Tool = '.$_GET['tool'].'';
		}
		elseif (empty($_POST['type'])  && empty($_POST['work']) && !empty($_POST['tool']) && intval($_POST['tool']))
		{
			$WHEREWORKS = 'typeCat IS NULL';
			$SET = 'p.Tool = '.$_POST['tool'].'';
			$_GET['tool'] = $_POST['tool'];
		}

		///
		elseif (!empty($_GET['type']) && intval($_GET['type']) && !empty($_GET['work']) && intval($_GET['work']) && empty($_GET['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
			$SET = 'p.Type = '.$_GET['type'].' AND p.Work = '.$_GET['work'].'';
		}
		elseif (!empty($_POST['type']) && intval($_POST['type']) && !empty($_POST['work']) && intval($_POST['work']) && empty($_POST['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
			$SET = 'p.Type = '.$_POST['type'].' AND p.Work = '.$_POST['work'].'';
			$_GET['type'] = $_POST['type'];
			$_GET['work'] = $_POST['work'];
		}

		///
		elseif (!empty($_GET['type']) && intval($_GET['type']) && empty($_GET['work']) && !empty($_GET['tool']) && intval($_GET['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
			$SET = 'p.Type = '.$_GET['type'].' AND p.Tool = '.$_GET['tool'].'';
		}
		elseif (!empty($_POST['type']) && intval($_POST['type']) && empty($_POST['work']) && !empty($_POST['tool']) && intval($_POST['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
			$SET = 'p.Type = '.$_POST['type'].' AND p.Tool = '.$_POST['tool'].'';
			$_GET['type'] = $_POST['type'];
			$_GET['tool'] = $_POST['tool'];
		}

		///
		elseif (!empty($_GET['type']) && intval($_GET['type']) && !empty($_GET['work']) && intval($_GET['work']) && !empty($_GET['tool']) && intval($_GET['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
			$SET = 'p.Type = '.$_GET['type'].' AND p.Work = '.$_GET['work'].' AND p.Tool = '.$_GET['tool'].'';
		}
		elseif (!empty($_POST['type']) && intval($_POST['type']) && !empty($_POST['work']) && intval($_POST['work']) && !empty($_POST['tool']) && intval($_POST['tool']))
		{
			$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
			$SET = 'p.Type = '.$_POST['type'].' AND p.Work = '.$_POST['work'].' AND p.Tool = '.$_POST['tool'].'';
			$_GET['type'] = $_POST['type'];
			$_GET['work'] = $_POST['work'];
			$_GET['tool'] = $_POST['tool'];
		}
		else
		{
			$WHEREWORKS = 'typeCat IS NULL';
			$SET = 'p.Type IS NOT NULL';
		}

		$TABLE_CATS = getTable('category_post cp');
		$TABLE_WORKS = getTable('work_parts wp WHERE '.$WHEREWORKS.'');
		$TABLE_TOOLS = getTable('tools t');

	[$REQ_POSTS, $TOTAL_PAGE, $PAGE_NOW, $displayPagination] = getPosts(''.$SET.'', 10);
	require('view/viewPosts.php');
}

function viewCatsWorks()
{	

	if (empty($_GET['works']))
	{
		header('Location: index.php?view=cats&works=1');
		exit();
	}

	$TABLE_WORKS = 'work_parts';
	$REQ_LIST = getTable('category_post cp LEFT JOIN work_parts wp ON cp.Type = wp.typeCat WHERE cp.Type ='.$_GET['works'].'');
	
	if (!empty($_GET['updateWorks']) AND intval($_GET['updateWorks']))
	{
		header('Location: index.php?view=cats&works='.$_GET['works'].'');
		$ID = $_GET['updateWorks'];
		$SET = 'nameWork = "'.$_POST['name'.$ID.''].'"';
		$WHERE = 'idWork = '.$ID.'';
		updateTable($TABLE_WORKS, $SET, $WHERE);
		exit();

	}
	elseif (isset($_GET['insertWorks'])) 
	{
		header('Location: index.php?view=cats&works='.$_GET['works'].'');
		$IDCAT = $_GET['works'];
		$ID = $_POST['idWork'];
		$NAME = ''.$_POST['nameWork'].'';
		
		$COLS = 'typeCat, idWork, nameWork';
		$VALUES = '"'.$IDCAT.'", "'.$ID.'", "'.$NAME.'"';
		rowExist($TABLE_WORKS, 'idWork', $ID);
		insertTable($TABLE_WORKS, $COLS, $VALUES);
		exit();
	}
	elseif (!empty($_GET['delWorks']) AND intval($_GET['delWorks']))
	{
		header('Location: index.php?view=cats&works='.$_GET['works'].'');
		$ID = $_GET['delWorks'];
		deleteTable($TABLE_WORKS, 'idwork', $ID);
		exit();
	}
	elseif (!empty($_GET['upWorks']) AND intval($_GET['upWorks']))
	{
		header('Location: index.php?view=cats&works='.$_GET['works'].'');
		$ID = $_GET['upWorks'];
		moveRow('UP', $TABLE_WORKS, 'idWork', $ID);
		exit();
	}
	elseif (!empty($_GET['downWorks']) AND intval($_GET['downWorks']))
	{
		header('Location: index.php?view=cats&works='.$_GET['works'].'');
		$ID = $_GET['downWorks'];
		moveRow('DOWN', $TABLE_WORKS, 'idWork', $ID);
		exit();
	}

	require 'view/viewCatsWorks.php';
}

function viewCatsTools()
{
	$TABLE_TOOLS = 'tools';
	$REQ_TOOLS = getTable($TABLE_TOOLS);

	if (!empty($_GET['updateTools']))
	{
		header('Location: index.php?view=cats');
		$ID = $_GET['updateTools'];
		$SET = 'nameTool = "'.$_POST['name'.$ID.''].'"';
		$WHERE = 'idTool = '.$ID.'';
		updateTable($TABLE_TOOLS, $SET, $WHERE);
		exit();
	}
	elseif (isset($_GET['insertTools']))
	{
		header('Location: index.php?view=cats');
		$ID = $_GET['insertTools'];
		$NAME = ''.$_POST['nameTool'].'';
		$COLS = 'idTool, nameTool';
		$VALUES = 'NULL, "'.$NAME.'"';
		insertTable($TABLE_TOOLS, $COLS, $VALUES);
		exit;
	}
	elseif (!empty($_GET['delTools']))
	{
		header('Location: index.php?view=cats');
		$ID = $_GET['delTools'];
		deleteTable($TABLE_TOOLS, 'idTool', $ID);
		exit;
	}
	require 'view/viewCatsTools.php';
}

function viewCats()
{

	$TABLE_CATS = 'category_post';
	$REQ_CATS = getTable($TABLE_CATS);

	if (!empty($_GET['updateCats']) AND intval($_GET['updateCats']))
	{
		header('Location: index.php?view=cats');
		$TYPE = $_GET['updateCats'];
		$SET = 'nameCat = "'.$_POST['name'.$TYPE.''].'", colorCat = "'.$_POST['clr'.$TYPE.''].'"';
		$WHERE = 'Type = '.$TYPE.'';
		updateTable($TABLE_CATS, $SET, $WHERE);
		exit();

	}
	elseif (isset($_GET['insertCats'])) 
	{
		header('Location: index.php?view=cats');
		$TYPE = $_POST['typeCat'];
		$NAME = ''.$_POST['nameCat'].'';
		$CLR = ''.$_POST['colorCat'].'';
		
		$COLS = 'Type, nameCat, colorCat';
		$VALUES = '"'.$TYPE.'", "'.$NAME.'", "'.$CLR.'"';
		rowExist($TABLE_CATS, 'Type', $TYPE);
		insertTable($TABLE_CATS, $COLS, $VALUES);
		exit();
	}
	elseif (!empty($_GET['delCats']) AND intval($_GET['delCats']))
	{
		header('Location: index.php?view=cats');
		$TYPE = $_GET['delCats'];
		deleteTable($TABLE_CATS, 'Type', $TYPE);
		exit();
	}
	elseif (!empty($_GET['upCats']) AND intval($_GET['upCats']))
	{
		header('Location: index.php?view=cats');
		$TYPE = $_GET['upCats'];
		moveRow('UP', $TABLE_CATS, 'Type', $TYPE);
		exit();
	}
	elseif (!empty($_GET['downCats']) AND intval($_GET['downCats']))
	{
		header('Location: index.php?view=cats');
		$TYPE = $_GET['downCats'];
		moveRow('DOWN', $TABLE_CATS, 'Type', $TYPE);
		exit();
	}
	require 'view/viewCats.php';
}