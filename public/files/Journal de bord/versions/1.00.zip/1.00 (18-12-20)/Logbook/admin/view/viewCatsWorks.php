<div class="works">
	<h1>Parties de travail:</h1>

	<?php
	echo'
		<p>
			<form method="post" action="index.php?view=cats&works='.$_GET['works'].'&insertWorks">
				<fieldset>
					ID: <input type="text" size="1" name="idWork" placeholder="ID" required />
					Nom: <input type="text" name="nameWork" placeholder="Nom de la partie" required />
					<input type="submit" value="Ajouter" />
				</fieldset>
			</form>
		</p>
	';

	while ($WORK = $REQ_LIST->fetch())
	{
		echo'
			<p>
				<form style="background-color: '.$WORK['colorCat'].';" method="post" action="index.php?view=cats&works='.$_GET['works'].'&updateWorks='.$WORK['idWork'].'">
					ID: '.$WORK['idWork'].', 
					Nom: <input type="text" name="name'.$WORK['idWork'].'" value="'.$WORK['nameWork'].'" />
					<input type="submit" value="Modifier" />
					<a href="index.php?view=cats&works='.$_GET['works'].'&upWorks='.$WORK['idWork'].'">UP</a> / <a href="index.php?view=cats&works='.$_GET['works'].'&downWorks='.$WORK['idWork'].'">DOWN</a>, <a href="index.php?view=cats&works='.$_GET['works'].'&delWorks='.$WORK['idWork'].'">Supprimer (!)</a>
				</form>
			</p>
		';
	}
	?>
</div>