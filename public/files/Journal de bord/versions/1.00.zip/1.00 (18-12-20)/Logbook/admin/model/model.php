<?php

	function activityIp()
	{
		$DB = dbConnect();
		$TABLE = 'activ_ip';
		$ip = getIP();
		$DATE = '"'.date('Y-m-d').'"';
		$TIME = '"'.date('H:i:s').'"';
		$view = '"'.$_SERVER['REQUEST_URI'].'"';
		$method = '"'.$_SERVER['REQUEST_METHOD'].'"';
		$host = '"'.gethostbyaddr($ip).'"';
		$userAgent = '"'.$_SERVER['HTTP_USER_AGENT'].'"';
		$lang = '"'.$_SERVER['HTTP_ACCEPT_LANGUAGE'].'"';

		$COLS = 'Id, ipAddr, dateVisit, timeVisit, view, method, ipHost, userAgent, accptLang';
		$VALUES = 'NULL, "'.$ip.'", '.$DATE.', '.$TIME.', '.$view.', '.$method.', '.$host.', '.$userAgent.', '.$lang.'';
		$RECORD = insertTable($TABLE, $COLS, $VALUES);
	}

	function getIP()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP']) && $_SERVER['HTTP_CLIENT_IP'] != $ip)
		{
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] != $ip)
		{
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else
		{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}

	function uploadImg($name, $dir)
	{
		if (!empty($_FILES['img']))
		{
			$targetDir = '../public/img/'.$dir;

			for ($i=0; $i<count($_FILES['img']['name']); $i++)
			{
				$nb = count(glob($targetDir . ''.$name.'*'));
				$oldName = explode('.', $_FILES['img']['name'][$i]);
				$newName = $name.$nb.'.'.end($oldName);
				$targetFile = $targetDir . $newName;
				move_uploaded_file($_FILES['img']['tmp_name'][$i], $targetFile);
			}
		}
	}

	function regexDate($string)
	{
		$string = preg_replace('#([0-3][0-9]{3})-([0-1][0-9])-([0-3][0-9])#isU', '$3/$2/$1' , $string);
		return $string;
	}

	function toBBCode($string)
	{
		$string = preg_replace('#\<strong\>(.+)\</strong\>#isU', '[b]$1[/b]', $string); //bold
		$string = preg_replace('#\<i\>(.+)\</i\>#isU', '[i]$1[/i]', $string); //italic
		$string = preg_replace('#\<u\>(.+)\</u\>#isU', '[u]$1[/u]', $string); //underline
		$string = preg_replace('#\<s\>(.+)\</s\>#isU', '[s]$1[/s]', $string); //crossout
		$string = preg_replace('#\<p\>(.+)\</p\>#isU', '[p]$1[/p]', $string); //paragraph
		$string = preg_replace('#\<img src\=\'(.+)\' /\>#isU', '[img]$1[/img]' , $string); //image
		$string = preg_replace('#\<img width\=\'([0-9]{1,2})\%\' height=\'([0-9]{1,2})\%\' src\=\'(.+)\' /\>#isU', '[img=$1]$3[/img]' , $string); //image with size 
		$string = preg_replace('#\<br /\>#isU', '' , $string); //br
		$string = preg_replace('#\<span style\=\'color\:\#([a-f0-9]{6})\'\>(.+)\</span\>#isU', '[color=#$1]$2[/color]', $string); //color
		$string = preg_replace('#\<div style\=\'text\-align\:(left|right|center|justify)\'\>(.+)\</div\>#isU', '[align=$1]$2[/align]', $string); //align
		$string = preg_replace('#\<div style\=\'float\:(right|left)\'\>(.+)\</div\>#isU', '[float=$1]$2[/float]' , $string); //float
		$string = preg_replace('#\<fieldset\>\<legend\>(.+)\</legend\>(.+)\</fieldset\>#isU', '[field=$1]$2[field]' , $string); //fieldset with name
		$string = preg_replace('#\<fieldset\>(.+)\</fieldset\>#isU', '[field]$1[/field]' , $string); //fieldset without name
		$string = preg_replace('#\<a href\=\'(.+)\'\>(.+)\</a\>#isU', '[url=$1]$2[/url]' , $string); //link

		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/smile.png\' /\>#isU', ':)' , $string); // :)
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/wink.png\' /\>#isU', ';)' , $string); // ;)
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/flat.png\' /\>#isU', ':|' , $string); // :|
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/cry.png\' /\>#isU', ':\'(' , $string); // :'(
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/sad.png\' /\>#isU', ':(' , $string); // :(
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/quiet.png\' /\>#isU', ':X' , $string); // :X
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/doubts.png\' /\>#isU', ':/' , $string); // :/
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/happy.png\' /\>#isU', ':D' , $string); // :D
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/happy2.png\' /\>#isU', 'xD' , $string); // xD
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/confused.png\' /\>#isU', ':S' , $string); // :S
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/tongue.png\' /\>#isU', ':P' , $string); // :P
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/surprised.png\' /\>#isU', ':O' , $string); // :O
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/mad.png\' /\>#isU', 'x(' , $string); // x(
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/bored.png\' /\>#isU', '-.-' , $string); // -.-
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/ninja.png\' /\>#isU', '^:' , $string); // ^:
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/angry.png\' /\>#isU', 'xO' , $string); // xO
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/suspicious.png\' /\>#isU', 'o_O' , $string); // o_O
		$string = preg_replace('#\<img class\=\'smiley\' src\=\'public/css/smileys/nerd.png\' /\>#isU', '._.' , $string); // ._.

		/*$string = preg_replace('#\<span style\=\'font\-size\:([1-9]{1,2})px\'>(.+)\</span\>#isU', '[size=$1]$2[/size]', $string); //size*/
		return $string;
	}

	function fromBBCode($field)
	{
		$string = htmlspecialchars($field);
		$string = preg_replace('#\[b\](.+)\[/b\]#isU', '<strong>$1</strong>', $string); //bold
		$string = preg_replace('#\[i\](.+)\[/i\]#isU', '<i>$1</i>', $string); //italic
		$string = preg_replace('#\[u\](.+)\[/u\]#isU', '<u>$1</u>', $string); //underline
		$string = preg_replace('#\[s\](.+)\[/s\]#isU', '<s>$1</s>', $string); //crossout
		$string = preg_replace('#\[p\](.+)\[/p\]#isU', '<p>$1</p>' , $string); //paragraph
		$string = preg_replace('#\[img\](.+)\[/img\]#isU', '<img src=\'$1\' />' , $string); //image
		$string = preg_replace('#\[img\=([0-9]{1,2})\](.+)\[/img\]#isU', '<img width=\'$1%\' height=\'$1%\' src=\'$2\' />' , $string); //image with size
		$string = preg_replace('#\\n#isU', '<br />' , $string); //br
		$string = preg_replace('#\[color\=\#([a-f0-9]{6})\](.+)\[/color\]#isU', '<span style=\'color:#$1\'>$2</span>', $string); //color
		$string = preg_replace('#\[align\=(left|right|center|justify)\](.+)\[/align\]#isU', '<div style=\'text-align:$1\'>$2</div>', $string); //align
		$string = preg_replace('#\[float\=(right|left)](.+)\[/float\]#isU', '<div style=\'float:$1\'>$2</div>' , $string); //float
		$string = preg_replace('#\[field\](.+)\[/field\]#isU', '<fieldset>$1</fieldset>' , $string); //fieldset without name
		$string = preg_replace('#\[field\=(.+)\](.+)\[/field\]#isU', '<fieldset><legend>$1</legend>$2</fieldset>' , $string); //fieldset with name
		$string = preg_replace('#\[url\](.+)\[/url\]#isU', '<a href=\'$1\'>$1</a>' , $string); //link
		$string = preg_replace('#\[url\=(.+)\](.+)\[/url\]#isU', '<a href=\'$1\'>$2</a>' , $string); //link=

		$string = preg_replace('# \:\)#isU', ' <img class=\'smiley\' src=\'public/css/smileys/smile.png\' />' , $string); // :)
		$string = preg_replace('# \;\)#isU', ' <img class=\'smiley\' src=\'public/css/smileys/wink.png\' />' , $string); // ;)
		$string = preg_replace('# \:\|#isU', ' <img class=\'smiley\' src=\'public/css/smileys/flat.png\' />' , $string); // :|
		$string = preg_replace('# \:\'\(#isU', ' <img class=\'smiley\' src=\'public/css/smileys/cry.png\' />' , $string); // :'(
		$string = preg_replace('# \:\(#isU', ' <img class=\'smiley\' src=\'public/css/smileys/sad.png\' />' , $string); // :(
		$string = preg_replace('# \:X#isU', ' <img class=\'smiley\' src=\'public/css/smileys/quiet.png\' />' , $string); // :X
		$string = preg_replace('# \:\/#isU', ' <img class=\'smiley\' src=\'public/css/smileys/doubts.png\' />' , $string); // :/
		$string = preg_replace('# \:D#isU', ' <img class=\'smiley\' src=\'public/css/smileys/happy.png\' />' , $string); // :D
		$string = preg_replace('# xD#isU', ' <img class=\'smiley\' src=\'public/css/smileys/happy2.png\' />' , $string); // xD
		$string = preg_replace('# \:S#isU', ' <img class=\'smiley\' src=\'public/css/smileys/confused.png\' />' , $string); // :S
		$string = preg_replace('# \:P#isU', ' <img class=\'smiley\' src=\'public/css/smileys/tongue.png\' />' , $string); // :P
		$string = preg_replace('# \:O#isU', ' <img class=\'smiley\' src=\'public/css/smileys/surprised.png\' />' , $string); // :O
		$string = preg_replace('# x\(#isU', ' <img class=\'smiley\' src=\'public/css/smileys/mad.png\' />' , $string); // x(
		$string = preg_replace('# \-\.\-#isU', ' <img class=\'smiley\' src=\'public/css/smileys/bored.png\' />' , $string); // -.-
		$string = preg_replace('# \^\:#isU', ' <img class=\'smiley\' src=\'public/css/smileys/ninja.png\' />' , $string); // ^:
		$string = preg_replace('# xO#isU', ' <img class=\'smiley\' src=\'public/css/smileys/angry.png\' />' , $string); // xO
		$string = preg_replace('# o\_O#isU', ' <img class=\'smiley\' src=\'public/css/smileys/suspicious.png\' />' , $string); // o_O
		$string = preg_replace('# \.\_\.#isU', ' <img class=\'smiley\' src=\'public/css/smileys/nerd.png\' />' , $string); // ._.

		/*$string = preg_replace('', '' , $string); //image*/
		/*$string = preg_replace('#\[size\=([1-9]{1,2})\](.+)\[/size\]#isU', '<span style=\'font-size:$1px\'>$2</span>', $string); //size*/
		return $string;
	}

/*Return null if choosen ID doesn't exist. */
	function getFullpost($idPost)
	{
		$DB = dbConnect();

		$REQ_POST = $DB->prepare('SELECT * FROM post p
								INNER JOIN category_post cp
								ON p.Type = cp.Type
								LEFT JOIN work_parts wp
								ON p.Work = wp.idWork
								LEFT JOIN tools t
								ON p.Tool = t.idTool
								WHERE idPost = '.$idPost.'');

 		$REQ_VERIF_EXIST = $DB->prepare('SELECT COUNT(idPost) AS NBID FROM post p WHERE idPost = ' .$idPost. '');
 		$REQ_VERIF_EXIST->execute();

 		if ($REQ_VERIF_EXIST->fetch()['NBID'] == 1)
		{
			$REQ_POST->execute();
			return $REQ_POST;
		}
	}

/*Set the param $wherePost with the entire content of WHERE.
Call $displayPagination to display page selection in the view.
Eg. getPosts('WHERE Tool = 1 AND Type IS NOT NULL')*/
	function getPosts($wherePost, $postByPage)
	{

		$DB = dbConnect();

		$REQ_TOTAL_POSTS = $DB->prepare('SELECT COUNT(idPost) AS total FROM post p WHERE '.$wherePost.' ');
		$REQ_TOTAL_POSTS->execute();
		$TOTAL_POSTS = $REQ_TOTAL_POSTS->fetch()['total'];
		$TOTAL_PAGE = ceil($TOTAL_POSTS / $postByPage);

		if(isset($_GET['pagint']) AND intval($_GET['pagint']) AND $_GET['pagint'] > 0)
		{
			$PAGE_NOW = $_GET['pagint'];
			if ($PAGE_NOW > $TOTAL_PAGE)
			{
				$PAGE_NOW = $TOTAL_PAGE;
			}
		}
		else
		{
			$PAGE_NOW = 1;
		}

		$FIRST_POST = ($PAGE_NOW - 1) * $postByPage;

		$REQ_POSTS = $DB->prepare('SELECT * FROM post p
							INNER JOIN category_post cp
							ON p.Type = cp.Type
							LEFT JOIN work_parts wp
							ON p.Work = wp.idWork
							LEFT JOIN tools t
							ON p.Tool = t.idTool
							WHERE '.$wherePost.'
							ORDER BY p.idPost DESC
							LIMIT '.$FIRST_POST.', '.$postByPage.'');

		$REQ_POSTS->execute(array());

		ob_start();
			for($PAGE=1; $PAGE <= $TOTAL_PAGE; $PAGE++)
			{
				if ($PAGE == $PAGE_NOW)
				{
				echo ' <strong> ' .$PAGE. ' </strong> ';
				}
				else
				{
					echo ' <a href="index.php?view=posts';
						if (!empty($_GET['type']) && intval($_GET['type']))
						{
							echo '&amp;type='.$_GET['type'].'';
						}

						if (!empty($_GET['work']) && intval($_GET['work']))
						{
							echo '&amp;work='.$_GET['work'].'';
						}

						if (!empty($_GET['tool']) && intval($_GET['tool']))
						{
							echo '&amp;tool='.$_GET['tool'].'';
						}

						echo '&amp;pagint='.$PAGE.'"> '.$PAGE.' </a>';
				}
			}
		$displayPagination = ob_get_clean();

		return [$REQ_POSTS, $TOTAL_PAGE, $PAGE_NOW, $displayPagination];
	}

/*Set $dir with UP or DOWN. Column and value have to be Integers (like an ID). */
	function moveRow($dir, $table, $column, $value)
	{
		$DB = dbConnect();
		switch($dir)
		{
			case 'UP':
				$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.'+1 WHERE '.$column.' > '.$value.' ORDER BY '.$column.' DESC');
				$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.'+2 WHERE '.$column.' = '.$value.'-1');
				$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.'-1 WHERE '.$column.' >= '.$value.'');
			break;

			case 'DOWN':
				$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.'-1 WHERE '.$column.' < '.$value.'');
				$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.'-2 WHERE '.$column.' = '.$value.'+1');
				$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.'+1 WHERE '.$column.' <= '.$value.' ORDER BY '.$column.' DESC');
			break;

			default;
				return 'Erreur, pas de direction annoncée';
			break;
		}
	}

/*Column and value have to be Integers (like an ID).
If row exist, the table make space to insert the new row*/
	function rowExist($table, $column, $value)
	{
		$DB = dbConnect();
		$EXIST = $DB->query('SELECT COUNT('.$column.') AS NB FROM '.$table.' WHERE '.$column.' = '.$value.'');
		if ($EXIST->fetch()['NB'] == 1)
		{
			$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.'+1 WHERE '.$column.' >= '.$value.' ORDER BY '.$column.' DESC');
		}
	}

/*All IDs after the deleted row are replaced correctly */
	function deleteTable($table, $column, $value)
	{
		$DB = dbConnect();
		$DEL = $DB->prepare('DELETE FROM '.$table.' WHERE '.$column.' = '.$value.'');
		$DEL->execute();
		$DB->query('UPDATE '.$table.' SET '.$column.' = '.$column.' - 1 WHERE '.$column.' >= '.$value.'');
	}

/*If you want to insert in a existing ID, use before rowExist() function*/
	function insertTable($table, $columns, $values)
	{
		$DB = dbConnect();
		$INSERT = $DB->prepare('INSERT INTO '.$table.' ('.$columns.') VALUES ('.$values.') ');
		$INSERT->execute();
	}

	function updateTable($table, $set, $where)
	{
		$DB = dbConnect();
		$UPDATE = $DB->prepare('UPDATE '.$table.' SET '.$set.' WHERE '.$where.' ');
		$UPDATE->execute();
	}

/*SELECT all elements of a choosen table in a simple query. Set a table. Need to be placed in a var and fetch it later.
Eg. $TABLE = getTable('posts'); then $TABLE->fetch()*/
	function getTable($tableName)
	{
		$DB = dbConnect();
		$QUERY = $DB->query('SELECT * FROM '.$tableName.' ');
		return $QUERY;
	}

/*Get content of "infos" table in a string. Set a nameInfo. Need to echo.
Eg. echo getInfos('Accueil');*/

	function getInfos($nameInfo)
	{
		$DB = dbConnect();

		$REQ_INFOS = $DB->prepare('SELECT contentInfo FROM infos WHERE nameInfo= ? ');
		$REQ_INFOS->execute(array($nameInfo));

		$CONTENT_INFO = $REQ_INFOS->fetch()['contentInfo'];

		return $CONTENT_INFO;
	}

/*Check if is entered a correct or wrong passwd. Set a valid namePass of your choice in the associated table.
With a html form, post method, send the var 'password'*/
	function validPass($namePass)
	{
		if (isset($_POST['password']) AND strval($_POST['password']) AND strlen($_POST['password']) < 16)
		{
			session_start();
			$DB = dbConnect();

			$REQ_PASSWD = $DB->prepare('SELECT thePass FROM passwds WHERE namePass = ?');

			$PASSWD_TYPE = htmlspecialchars($_POST['password']);
			$REQ_PASSWD->execute(array($namePass));
			$PASSWD = $REQ_PASSWD->fetch()['thePass'];

			if ($PASSWD_TYPE == $PASSWD)
			{
				header('Location: index.php');
				$_SESSION[''.$namePass.''] = $PASSWD;
				exit();
			}
			else
			{
				header('Location: index.php');
				$_SESSION[''.$namePass.''] = NULL;
				exit();
			}
			$REQ_PASSWD->closeCursor();
		}
	}

/*Compare the session cookie with table password. Security. Return true or false*/
	function isValidPass($namePass)
	{
		$DB = dbConnect();

		$REQ_PASSWD = $DB->prepare('SELECT thePass FROM passwds WHERE namePass = ?');
		$REQ_PASSWD->execute(array($namePass));
		$PASSWD = $REQ_PASSWD->fetch()['thePass'];

		if(isset($_SESSION[''.$namePass.'']) && $_SESSION[''.$namePass.''] === $PASSWD)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
/*Connect to the database. Catch error if doesn't work.*/
	function dbConnect()
	{
		try
		{
			$DB =  new PDO('mysql:host=localhost;dbname=cahier_de_bord;charset=utf8', 'root', 'root', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			return $DB;
		}
		catch(Exception $e)
		{
			die('Erreur: ' . $e->getMessage());
		}
	}