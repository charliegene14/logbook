<!DOCTYPE html>
<html>
 	<head>
 		<meta charset="utf-8" />
 		<title><?= $pageTitle ?> - Cahier de bord, Charlie-Gene</title>
 		<link rel="stylesheet" href="public/css/style.css" />
 	</head>

 	<body>
 		<header>
			<h1><?= getInfos('Head'); ?></h1>
		</header>

		<?= $pageContent ?>
	
		<footer>
			<p><?= getInfos('Foot'); ?></p>
		</footer>
 	</body>
</html>