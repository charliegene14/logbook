<?php
require('controller/adminController.php');
session_start();
activityIp();

if (empty($_SESSION['Site']) && isValidPass('Site') === false)
{
	header('Location: ../index.php');
	exit();
}

if (!empty($_SESSION['Admin']) && isValidPass('Admin') === true)
{
	if (isset($_GET['view']))
	{
		$VIEWADMIN = $_GET['view'];
		switch($VIEWADMIN)
		{
			case 'navigation':
				viewNavigation();
			break;

			case 'cats':
				viewCats();
			break;

			case 'posts':
				viewPosts();
			break;

			case 'postupdate':
				viewPostUpdate();
			break;

			case 'postinsert':
				viewPostInsert();
			break;

			case 'pages':
				viewPages();
			break;

			case 'pagecontent':
				viewPageContent();
			break;

			case 'connected':
				viewConnected();
			break;

			case 'error':
				Error();
			break;

			default:
				viewPanel();
			break;
		}
	}
	else
	{
		viewPanel();
	}
}
else
{
	viewBlock();
}