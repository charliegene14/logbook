<?php $pageTitle = 'Erreur'; ?>
<?php ob_start(); ?>

<section class="error">
	<article>
		<p>Désolé, il n'y a rien ici</p>
	</article>
</section>

<?php $pageContent = ob_get_clean(); ?>
<?php require('template.php'); ?>