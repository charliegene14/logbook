<div class="tools">
	<p>
		<form method="post" action="index.php?view=cats&insertTools">
			<fieldset>
					<input type="text" name="nameTool" size="6" placeholder="Nom de l'outil" required /><br />
					<input type="submit" value="Ajouter" />
			</fieldset>
		</form>
	</p>

	<?php
	while($TOOL = $REQ_TOOLS->fetch())
	{
		echo '
			<p>
				<form method="post" action="index.php?view=cats&updateTools='.$TOOL['idTool'].'">
					<fieldset>
							<input type="text" size="6" name="name'.$TOOL['idTool'].'" value="'.$TOOL['nameTool'].'" required /><br />
							<input type="submit" value="Modifier" />
							<a href="index.php?view=cats&delTools='.$TOOL['idTool'].'">(X)</a>
					</fieldset>
				</form>
			</p>
		';
	}
	$REQ_TOOLS->closeCursor();
	?>
</div>