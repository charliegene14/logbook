<?php $pageTitle = 'Activités du site'; ?>
<?php ob_start(); ?>

<section class="viewConnected">

	<div class="lastConnexion">
		<p><a href="index.php">Retourner au panneau principal</a></p>
		<p><i>(<?= $REQ_TOTAL_VISIT->fetch()['totalIp']?> visiteurs au total)</i></p>
		<fieldset>
		<?php

		while ($IP = $REQ_IP_LIST->fetch())
		{
			if ($IP['ipAddr'] == $_GET['ip'])
			{
				echo '<p>-->><span style="background-color: purple; color: white; border-radius: 5px"><b>'.$IP['ipAddr'].'</b> : last at '.regexDate($IP['lastVisit']).' ('.$IP['totalViews'].' views)</span> >> </p>';
			}
			else
			{
				echo '<p><a style="background-color: darkgrey; color: black; border-radius: 5px" href="index.php?view=connected&ip='.$IP['ipAddr'].'&date='.$IP['lastVisit'].'">'.$IP['ipAddr'].'</a> : last at '.regexDate($IP['lastVisit']).' ('.$IP['totalViews'].' views)</p>';
			}
		}
		$REQ_IP_LIST->closeCursor();
		?>
		</fieldset>
	</div>

	<? viewConnectedDate(); ?>
	<? viewConnectedDetails(); ?>
</section>

<?php $pageContent = ob_get_clean(); ?>
<?php require('template.php'); ?>