<?php $pageTitle='Gestion des Catégories'; ?>
<?php ob_start(); ?>

<section class="viewCats">
	<p><a href="index.php">Retourner au panneau principal</a></p>

	<?php viewCatsTools(); ?>

	<div class="cats">
		<p><h1>Catégories:</h1></p>

		<p>
			<form method="post" action="index.php?view=cats&insertCats">
				<fieldset>
					Type: <input type="text" size="1" name="typeCat" placeholder="Type" required /><br />
					Nom: <input type="text" name="nameCat" placeholder="Nom de la cat." required /><br />
					Couleur: <input type="color" name="colorCat" placeholder="Couleur d'identification" required /><br />
					<input type="submit" value="Ajouter" />
				</fieldset>
			</form>
		</p>

		<?php
		while($CAT = $REQ_CATS->fetch())
		{
			echo'
				<p>
					<form style="background-color: '.$CAT['colorCat'].';" method="post" action="index.php?view=cats&updateCats='.$CAT['Type'].'">
						Type: '.$CAT['Type'].'<br />
						Nom: <input type="text" name="name'.$CAT['Type'].'" value="'.$CAT['nameCat'].'" required /><br />
						Couleur: <input type="color" name="clr'.$CAT['Type'].'" value="'.$CAT['colorCat'].'" required /><br />
						<input type="submit" value="Modifier" />
						<a href="index.php?view=cats&upCats='.$CAT['Type'].'">UP</a> / <a href="index.php?view=cats&downCats='.$CAT['Type'].'">DOWN</a>, <a href="index.php?view=cats&delCats='.$CAT['Type'].'"> SUPPRIMER (!)</a><br />
						<a href="index.php?view=cats&works='.$CAT['Type'].'">Gestion des différentes parties de travail</a>
					</form>
				</p>
			';
		}
		$REQ_CATS->closeCursor();
		?>

	</div>

	<?php viewCatsWorks(); ?>

</section>

<?php $pageContent = ob_get_clean(); ?>
<?php require 'template.php' ?>