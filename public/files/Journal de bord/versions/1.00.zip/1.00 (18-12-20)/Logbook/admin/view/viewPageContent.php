<?php $pageTitle='Gérer le contenu de page'; ?>
<?php ob_start(); ?>

<section class="viewPageContent">
	<p><a href="index.php?view=pages">Retourner au gestionnaire de pages</a></p>

	<?php
	echo '<h1>"'.$PAGE['titlePage'].'"</h1>

		<form method="post" action="index.php?view=pagecontent&id='.$ID.'&update" enctype="multipart/form-data">
			<fieldset>
				<legend>Insertion d\'images</legend>
				<input type="file" name="img[]" multiple />
				<p>';

				if ($numberOfImg >= 1)
				{
					for ($i=0; $i<$numberOfImg; $i++)
					{
						echo'<img src="../public/img/pages/'.$PAGE['titlePage'].$i.'.png" width="20%" height="20%" /><a href="../public/img/pages/'.$PAGE['titlePage'].$i.'.png">public/img/pages/'.$PAGE['titlePage'].$i.'.png</a>';
					}
				}
				echo'</p>
			</fieldset>

			<fieldset>
				<legend>Contenu</legend>
					<textarea name="contentPost" rows="40" cols="100">'.$PAGE['contentPage'].'</textarea>
			</fieldset>

			<input type="submit" value="Modifier" />

		</form>';
		$REQ_PAGE->closeCursor();
	?>
</section>

<?php $pageContent = ob_get_clean(); ?>
<?php require 'template.php' ?>