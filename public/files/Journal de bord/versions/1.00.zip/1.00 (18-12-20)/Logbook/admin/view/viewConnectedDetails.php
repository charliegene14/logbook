<div class="viewConnectedDetails">
		<?php
		while ($DETAIL = $REQ_DETAILS_LIST->fetch())
		{?>

			<fieldset>
				<p>
					<b><?=$DETAIL['timeVisit']?></b>: (<i><?=$DETAIL['ipHost']?></i>)<br /><?=$DETAIL['view'] ?><br /> <b>METHOD:</b> <?= $DETAIL['method'] ?><br />
					<b>AGENT:</b> <?=$DETAIL['userAgent']?><br />
					<b>LANG:</b> <?=$DETAIL['accptLang']?>
				</p>
			</fieldset>

		<?}
		?>
</div>