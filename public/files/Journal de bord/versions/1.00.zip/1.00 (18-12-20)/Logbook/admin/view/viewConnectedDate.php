<div class="viewConnectedDate">
	<fieldset>
		<?php
		while ($LIST = $REQ_DATE_LIST->fetch())
		{
			if ($LIST['dateVisit'] == $_GET['date'])
			{
				echo '<p>-->><span style="background-color: purple; color: white; border-radius: 5px"><b>'.regexDate($LIST['dateVisit']).'</b> ('.$LIST['viewsDate'].' views)</span> >></p>';
			}
			else
			{
				echo '<p><a style="background-color: darkgrey; color: black; border-radius: 5px" href="index.php?view=connected&ip='.$_GET['ip'].'&date='.$LIST['dateVisit'].'">'.regexDate($LIST['dateVisit']).' ('.$LIST['viewsDate'].' views)</a></p>';
			}
		}
		?>
	</fieldset>
</div>