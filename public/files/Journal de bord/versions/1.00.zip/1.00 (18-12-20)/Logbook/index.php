<?php
require('controller/indexController.php'); //Get the  controller for MVC architecturing

try
{
	session_start();
	activityIp();

	if (!empty($_SESSION['Site']) && isValidPass('Site') === true)
	{
		if (!empty($_GET['view']))
		{
			$VIEW = $_GET['view'];
			switch ($VIEW)
			{
				case 'posts':
					viewPosts();
				break;

				case 'fullpost':
					viewFullpost();
				break;

				case 'onwork':
					onWorking();
				break;

				default:
					throw new Exception('Désolé, la page demandée n\'éxiste pas.');
				break;
			}
		}
		elseif (!empty($_GET['page']))
		{
			viewPage($_GET['page']);
		}
		else
		{
			viewAccueil();
		}
	}
	else
	{
		viewBlock();
	}
}
catch (Exception $e)
{
	Error($e->getMessage());
}