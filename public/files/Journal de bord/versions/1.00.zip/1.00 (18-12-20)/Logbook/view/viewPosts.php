<?php $pageTitle = 'Articles'; ?>
<?php ob_start(); ?>

<section class="news">

	<aside class="sort">
		<form method="post" action="index.php?view=posts">
			<fieldset>

				<select name="type" onChange="this.form.submit()">
					<option value="">Toute catégorie</option>
					<?php
						while ($CAT = $TABLE_CATS->fetch())
						{
							echo '<option value="'.$CAT['Type'].'"';
							if (!empty($_POST['type']) && $_POST['type'] == $CAT['Type'] OR !empty($_GET['type']) && $_GET['type'] == $CAT['Type'])
							{
								echo 'selected';
							}
							echo '>'.$CAT['nameCat'].'</option>';
						}
						$TABLE_CATS->closeCursor();
					?>
				</select>

				<select name="work" onChange="this.form.submit()">
					<option value="">Toute partie de travail</option>
					<?php
						while ($WORK = $TABLE_WORKS->fetch())
						{
							echo '<option value="'.$WORK['idWork'].'"';
							if (!empty($_POST['work']) && $_POST['work'] == $WORK['idWork'] OR !empty($_GET['work']) && $_GET['work'] == $WORK['idWork'])
							{
								echo 'selected';
							}
							echo '>'.$WORK['nameWork'].'</option>';
						}
						$TABLE_WORKS->closeCursor();
					?>
				</select>

				<select name="tool" onChange="this.form.submit()">
					<option value="">Tous les outils</option>
					<?php
						while ($TOOL = $TABLE_TOOLS->fetch())
						{
							echo '<option value="'.$TOOL['idTool'].'"';
							if (!empty($_POST['tool']) AND $_POST['tool'] == $TOOL['idTool'] OR !empty($_GET['tool']) && $_GET['tool'] == $TOOL['idTool'])
							{
								echo 'selected';
							}
							echo '>'.$TOOL['nameTool'].'</option>';
						}
						$TABLE_TOOLS->closeCursor();
					?>
				</select>

			</fieldset>
		</form>
	</aside>

	<?php
		while ($POST = $REQ_POSTS->fetch())
		{
			echo'
				<article>

				    <h1><a href="index.php?view=fullpost&amp;id=' .$POST['idPost'].'">' .$POST['titlePost']. '</a></h1>

					<h2>
						(dans <a style="color: ' .$POST['colorCat']. '" href="index.php?view=posts&amp;type=' .$POST['Type']. '"><b>' .$POST['nameCat']. '</b></a>)<br />
						<img src="public/css/datePost.png" />le ' .regexDate($POST['datePost']). '
					</h2>

					<div class="content_new">';
						if (strlen(regexPreviewPost($POST['contentPost'])) > $MAX_LENGTH)
						{
							echo (substr(regexPreviewPost($POST['contentPost']), 0, $MAX_LENGTH).'[...].<br /><a href="index.php?view=fullpost&amp;id=' .$POST['idPost'].'">Lire la suite</a>');
						}
						else
						{
							echo (regexPreviewPost($POST['contentPost']));
						}
						echo '
					</div>
					<p>
						<hr />
					</p>
				</article>';
		}
	?>

	<p class="pages">
		<?= $displayPagination; ?>
	</p>

	<? $REQ_POSTS->closeCursor(); ?>
</section>

<?php $pageContent = ob_get_clean(); ?>
<?php require('template.php'); ?>