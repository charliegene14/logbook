<!DOCTYPE html>
<html>

 	<head>
 		<meta charset="utf-8" />
 		<title><?= $pageTitle ?> - Cahier de bord, Charlie-Gene</title>
 		<link rel="stylesheet" href="public/css/style.css" />
 	</head>


 	<body>

 		<header>
			<h1><a href="index.php"><?= getInfos('Head'); ?></a></h1>
		</header>

		<div class="nav1">
			<nav>
				<ul>

				<? 
				$TABLE_NAV = getTable('navigation');
				$TABLE_CAT = getTable('category_post');
				while ($MENU = $TABLE_NAV->fetch())
				{

					echo'<li><a href="'.$MENU['linkNav']. '">' .$MENU['nameNav']. '</a>';

					if ($MENU['nameNav'] == 'Articles')
					{
						echo '<ul>';

						while($MENU_CAT = $TABLE_CAT->fetch())
						{
							echo '<li><a href="index.php?view=posts&amp;type=' .$MENU_CAT['Type']. '">' .$MENU_CAT['nameCat']. '</a></li>';
						}

						echo '</ul>';
					}
										
					echo'</li>';
				}

		
				$TABLE_CAT->closeCursor();
				$TABLE_NAV->closeCursor();
				?>

				</ul>	
			</nav>
		</div>

		<?= $pageContent ?>
	
		<footer>
			<p><?= getInfos('Foot'); ?></p>
		</footer>

 	</body>


</html>