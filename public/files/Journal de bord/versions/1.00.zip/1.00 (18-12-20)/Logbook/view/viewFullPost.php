<?php ob_start(); ?>

<section class="news">
	<article>

		<?php
			$POST = $REQ_POST->fetch();
			$pageTitle = ''.$POST['titlePost'].'';

			echo'
				<h1><a href="index.php?view=fullpost&amp;id=' .$POST['idPost'].'">' .$POST['titlePost']. '</a></h1>';
				    
				    if ($POST['Work'] != NULL)
					{
						echo '<img src="public/css/workPost.png" />'.$POST['nameWork'].'<br />';
					}
					else
					{
						echo '<img src="public/css/workPost.png" />Dans aucune partie de travail<br />';
					}
				    if ($POST['Tool'] != NULL)
					{
						echo '<img src="public/css/toolPost.png" />'.$POST['nameTool'].'<br />';
					}
					else
					{
						echo '<img src="public/css/toolPost.png" />Aucun outil<br />';
					}
				    echo'
		    			<img src="public/css/timePost.png" />'.regexTime($POST['timePost']).'

				<h2>
					(dans <a style="color: ' .$POST['colorCat']. '" href="index.php?view=posts&amp;type=' .$POST['Type']. '"><b>' .$POST['nameCat']. '</b></a>)<br />
					<img src="public/css/datePost.png" />le ' .regexDate($POST['datePost']). '
				</h2>

				<div class="content_new">';
					echo ''.$POST['contentPost'].'
				</div>';

			$REQ_POST->closeCursor();

		?>
	</article>
</section>

<?php $pageContent = ob_get_clean(); ?>
<?php require('template.php'); ?>