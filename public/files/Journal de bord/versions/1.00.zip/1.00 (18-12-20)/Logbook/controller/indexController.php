<?php
	require('model/model.php'); //Get the model for MVC architecturing

	function viewPage($fileName)
	{
		if (isExist('pages WHERE fileName = "'.$fileName.'"', 'idPage'))
		{
			$REQ_PAGE = getTable('pages WHERE fileName = "'.$fileName.'"');
			$PAGE = $REQ_PAGE->fetch();
			require 'view/viewPage.php';
		}
		else
		{
			throw new Exception('404 - Désolé, la page demandée n\'éxiste pas.');
			
		}
	}

	function onWorking()
	{
		require 'view/viewWorking.php';
	}

	function Error($message)
	{
		require('view/viewError.php');
	}

	function viewBlock()
	{
		validPass('Site');
		require('view/viewBlock.php');
	}

	function viewAccueil()
	{
		require('view/viewAccueil.php');
	}

	function viewPosts()
	{
		$MAX_LENGTH = 400;

			///
			if (!empty($_GET['type'])
			&& intval($_GET['type'])
			&& empty($_GET['work'])
			&& empty($_GET['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
				$SET = 'p.Type = '.$_GET['type'].'';
			}
			elseif (!empty($_POST['type'])
			&& intval($_POST['type'])
			&& empty($_POST['work'])
			&& empty($_POST['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
				$SET = 'p.Type = '.$_POST['type'].'';
				$_GET['type'] = $_POST['type'];
			}

			///
			elseif (empty($_GET['type'])
			&& empty($_GET['work'])
			&& !empty($_GET['tool'])
			&& intval($_GET['tool']))
			{
				$WHEREWORKS = 'typeCat IS NULL';
				$SET = 'p.Tool = '.$_GET['tool'].'';

			}
			elseif (empty($_POST['type']) 
			&& empty($_POST['work'])
			&& !empty($_POST['tool'])
			&& intval($_POST['tool']))
			{
				$WHEREWORKS = 'typeCat IS NULL';
				$SET = 'p.Tool = '.$_POST['tool'].'';
				$_GET['tool'] = $_POST['tool'];
			}

			///
			elseif (!empty($_GET['type'])
			&& intval($_GET['type'])
			&& !empty($_GET['work'])
			&& intval($_GET['work'])
			&& empty($_GET['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
				$SET = 'p.Type = '.$_GET['type'].' AND p.Work = '.$_GET['work'].'';
			}
			elseif (!empty($_POST['type'])
			&& intval($_POST['type'])
			&& !empty($_POST['work'])
			&& intval($_POST['work'])
			&& empty($_POST['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
				$SET = 'p.Type = '.$_POST['type'].' AND p.Work = '.$_POST['work'].'';
				$_GET['type'] = $_POST['type'];
				$_GET['work'] = $_POST['work'];
			}

			///
			elseif (!empty($_GET['type'])
			&& intval($_GET['type'])
			&& empty($_GET['work'])
			&& !empty($_GET['tool'])
			&& intval($_GET['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
				$SET = 'p.Type = '.$_GET['type'].' AND p.Tool = '.$_GET['tool'].'';
			}
			elseif (!empty($_POST['type'])
			&& intval($_POST['type'])
			&& empty($_POST['work'])
			&& !empty($_POST['tool'])
			&& intval($_POST['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
				$SET = 'p.Type = '.$_POST['type'].' AND p.Tool = '.$_POST['tool'].'';
				$_GET['type'] = $_POST['type'];
				$_GET['tool'] = $_POST['tool'];
			}

			///
			elseif (!empty($_GET['type'])
			&& intval($_GET['type'])
			&& !empty($_GET['work'])
			&& intval($_GET['work'])
			&& !empty($_GET['tool'])
			&& intval($_GET['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_GET['type'].'';
				$SET = 'p.Type = '.$_GET['type'].' AND p.Work = '.$_GET['work'].' AND p.Tool = '.$_GET['tool'].'';
			}
			elseif (!empty($_POST['type'])
			&& intval($_POST['type'])
			&& !empty($_POST['work'])
			&& intval($_POST['work'])
			&& !empty($_POST['tool'])
			&& intval($_POST['tool']))
			{
				$WHEREWORKS = 'typeCat = '.$_POST['type'].'';
				$SET = 'p.Type = '.$_POST['type'].' AND p.Work = '.$_POST['work'].' AND p.Tool = '.$_POST['tool'].'';
				$_GET['type'] = $_POST['type'];
				$_GET['work'] = $_POST['work'];
				$_GET['tool'] = $_POST['tool'];
			}
			else
			{
				$WHEREWORKS = 'typeCat IS NULL';
				$SET = 'p.Type IS NOT NULL';
			}

			if (!empty($_GET['type'])
			&& !isExist('category_post WHERE Type ='.$_GET['type'].'', 'Type'))
			{
				throw new Exception('Désolé, la catégorie demandée n\'éxiste pas.');
			}

			if (!empty($_GET['work'])
			&& !empty($_GET['type'])
			&& !isExist('work_parts WHERE idWork ='.$_GET['work'].' AND typeCat = '.$_GET['type'].'', 'idWork'))
			{
				throw new Exception('Désolé, la partie de travail demandée n\'éxiste pas.');
			}

			if (!empty($_GET['work'])
			&& empty($_GET['type']))
			{
				throw new Exception('Désolé, une erreur s\'est produite.');
			}

			if (!empty($_GET['tool'])
			&& !isExist('tools WHERE idTool ='.$_GET['tool'].'', 'idTool'))
			{
				throw new Exception('Désolé, l\'outil demandé n\'éxiste pas.');
			}

			$TABLE_CATS = getTable('category_post cp');
			$TABLE_WORKS = getTable('work_parts wp WHERE '.$WHEREWORKS.'');
			$TABLE_TOOLS = getTable('tools t');

			[$REQ_POSTS, $TOTAL_PAGE, $PAGE_NOW, $displayPagination] = getPosts(''.$SET.'', 4);
			require('view/viewPosts.php');
	}


	function viewFullpost()
	{

		if (!empty($_GET['id']) AND intval($_GET['id']))
		{
			if(!empty(getFullPost($_GET['id'])))
			{
				$REQ_POST = getFullPost($_GET['id']);
				require('view/viewFullpost.php');
			}
			else
			{
				throw new Exception('Désolé, l\'article demandé n\'éxiste pas.');
			}
		}
		
		else
		{	
			throw new Exception('Désolé, aucun article ici.');
		}
		
	}