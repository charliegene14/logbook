<?php

require_once 'model/database.php';

class dbTools extends database
{
	public function getAll()
	{
		$DB = $this->dbConnect();
		$QUERY = $DB->query('SELECT * FROM tools');
		return $QUERY;
	}

	public function getByType($typeCat)
	{
		$DB= $this->dbConnect();
		$QUERY = $DB->prepare("SELECT t.idTool, t.nameTool FROM tools t
								INNER JOIN post p 
								ON t.idTool = p.Tool
								WHERE p.Type = ?
								GROUP BY t.idTool");

			$QUERY->execute(array($typeCat));
			return $QUERY;

	}

	public function getByWork($idWork)
	{
		$DB= $this->dbConnect();
		$QUERY = $DB->prepare("SELECT t.idTool, t.nameTool FROM tools t
								INNER JOIN post p 
								ON t.idTool = p.Tool
								WHERE p.Work = ?
								GROUP BY t.idTool");

		$QUERY->execute(array($idWork));
		return $QUERY;
	}
}