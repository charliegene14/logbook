<?php
require_once 'model/dbProjects.php';
require_once 'model/regex.php';

function viewFullproject()
{
	if (empty($_GET['id']) OR !intval($_GET['id']))
	{
		throw new Exception('Désolé, aucun projet ici.');
	}
	else
	{
		$dbProj = new dbProjects();
		$regex = new Regex();
		
		$list = $dbProj->getAll();

		$PROJ = $dbProj->getProject($_GET['id']);

		require 'view/viewFullproject.php';
	}
}